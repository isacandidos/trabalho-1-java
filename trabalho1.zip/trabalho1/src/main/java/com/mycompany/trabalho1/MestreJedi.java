/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho1;

/**
 *
 * @author isadora
 */
public class MestreJedi extends Jedi implements Raios {

    public void setForça(int força) {
        this.força = 100;
    }

    @Override
    public String cor() {
        throw new UnsupportedOperationException("Cor do Raio"); 
    }

    @Override
    public int forçaExtra() {
        throw new UnsupportedOperationException("Força extra"); 
    }

    @Override
    public void usarRaio() {
        throw new UnsupportedOperationException("usar Raio"); 
    }

   
    
    
}
